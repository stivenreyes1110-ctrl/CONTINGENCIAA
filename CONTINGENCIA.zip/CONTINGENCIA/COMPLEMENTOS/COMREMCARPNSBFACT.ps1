﻿# ==========================================
# AGREGAR "NSB" AL INICIO DE LAS CARPETAS
# Ruta fija: C:\CONTINGENCIA\NUEVAS
# ==========================================

$RutaBase = "C:\CONTINGENCIA\NUEVAS"

# Validar que exista la ruta
if (!(Test-Path $RutaBase)) {
    Write-Host "❌ La ruta no existe: $RutaBase" -ForegroundColor Red
    exit
}

Write-Host "🔎 Revisando carpetas en $RutaBase ..." -ForegroundColor Cyan

# Obtener solo carpetas
$Carpetas = Get-ChildItem -Path $RutaBase -Directory

foreach ($Carpeta in $Carpetas) {

    $NombreActual = $Carpeta.Name

    # Verificar si NO empieza por NSB
    if ($NombreActual -notmatch "^NSB") {

        $NuevoNombre = "NSB" + $NombreActual
        $RutaNueva = Join-Path $RutaBase $NuevoNombre

        # Validar que no exista ya una carpeta con el nuevo nombre
        if (!(Test-Path $RutaNueva)) {
            Rename-Item $Carpeta.FullName $NuevoNombre
            Write-Host "✅ Renombrada: $NombreActual  →  $NuevoNombre" -ForegroundColor Green
        }
        else {
            Write-Host "⚠️ Ya existe: $NuevoNombre (No se renombra)" -ForegroundColor Yellow
        }

    }
    else {
        Write-Host "✔ Ya tiene NSB: $NombreActual" -ForegroundColor Gray
    }
}

Write-Host "🏁 Proceso finalizado." -ForegroundColor Cyan
