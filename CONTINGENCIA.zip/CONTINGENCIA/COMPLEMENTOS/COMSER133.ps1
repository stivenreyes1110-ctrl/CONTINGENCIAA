﻿# ==========================================================
# EJERCICIO 1:
# - Entrar a la PRIMERA carpeta de $RutaCompartida
# - Intentar buscar en NIVEL 6
# - Si no existe, bajar a NIVEL 5,4,3,2,1 (fallback)
# - Buscar carpetas por nombre (Excel Col A)
# - Copiar carpeta completa a $DestinoLocal con ROBOCOPY
# ==========================================================

$RutaCompartida = "\\128.0.13.3\compensar\RADICAION VIRTUAL 2022"
$ExcelPath      = "C:\CONTINGENCIA\RELACION.xlsx"
$DestinoLocal   = "C:\CONTINGENCIA\ANTIGUAS"

# Robocopy controlado
$RoboMT  = 4
$RoboIPG = 0   # si quieres limitar red: 10 o 20

# ---------- Preparar destino y logs ----------
New-Item -ItemType Directory -Force -Path $DestinoLocal | Out-Null
$LogDir = Join-Path $DestinoLocal "_LOGS"
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null

$LogEncontradas = Join-Path $LogDir "encontradas.txt"
$LogNoEncontr   = Join-Path $LogDir "no_encontradas.txt"
$LogErrores     = Join-Path $LogDir "errores.txt"

"" | Set-Content $LogEncontradas
"" | Set-Content $LogNoEncontr
"" | Set-Content $LogErrores

# ---------- Leer Excel (Col A) ----------
try {
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false

    $wb = $excel.Workbooks.Open($ExcelPath)
    $ws = $wb.Sheets.Item(1)

    $pendientes = New-Object System.Collections.Generic.HashSet[string]
    $row = 1
    while ($true) {
        $val = $ws.Cells.Item($row, 1).Text
        if ([string]::IsNullOrWhiteSpace($val)) { break }
        $null = $pendientes.Add($val.Trim())
        $row++
    }

    $wb.Close($false)
    $excel.Quit()
}
catch {
    Add-Content $LogErrores "ERROR leyendo Excel: $($_.Exception.Message)"
    Write-Host "ERROR leyendo Excel. Revisa: $LogErrores"
    exit
}

if ($pendientes.Count -eq 0) {
    Write-Host "No hay nombres en la columna A del Excel."
    exit
}

Write-Host "Pendientes iniciales: $($pendientes.Count)"

# ---------- Función copiar carpeta completa ----------
function Copiar-Carpeta {
    param([string]$Origen, [string]$Destino)

    New-Item -ItemType Directory -Force -Path $Destino | Out-Null

    $args = @(
        $Origen, $Destino,
        "/E",
        "/COPY:DAT", "/DCOPY:DAT",
        "/R:1", "/W:1",
        "/MT:$RoboMT",
        "/NP", "/NFL", "/NDL"
    )
    if ($RoboIPG -gt 0) { $args += "/IPG:$RoboIPG" }

    $p = Start-Process -FilePath "robocopy.exe" -ArgumentList $args -NoNewWindow -PassThru -Wait
    if ($p.ExitCode -ge 8) {
        throw "Robocopy falló con ExitCode $($p.ExitCode)"
    }
}

# ---------- Función: bajar a nivel X desde una raíz ----------
function Get-FoldersAtDepth {
    param(
        [Parameter(Mandatory=$true)][string]$BasePath,
        [Parameter(Mandatory=$true)][int]$Depth
    )
    $current = @($BasePath)

    for ($i = 1; $i -le $Depth; $i++) {
        $next = New-Object System.Collections.Generic.List[string]
        foreach ($p in $current) {
            try {
                $children = Get-ChildItem -Path $p -Directory -ErrorAction SilentlyContinue
                foreach ($c in $children) { $null = $next.Add($c.FullName) }
            } catch {}
        }
        $current = $next.ToArray()
        if ($current.Count -eq 0) { break }
    }
    return $current
}

# ---------- Función: Procesar lote (escaneo 1 vez, copiar, descartar) ----------
function Procesar-Lote {
    param([Parameter(Mandatory=$true)][string]$RutaLote)

    if ($pendientes.Count -eq 0) { return }

    Write-Host "Escaneando lote: $RutaLote | Pendientes: $($pendientes.Count)"

    $map = @{}
    try {
        Get-ChildItem -Path $RutaLote -Directory -Recurse -ErrorAction SilentlyContinue |
        ForEach-Object {
            if (-not $map.ContainsKey($_.Name)) { $map[$_.Name] = $_.FullName }
        }
    } catch {
        Add-Content $LogErrores "ERROR escaneando $RutaLote $($_.Exception.Message)"
        return
    }

    $encontradasAqui = @()
    foreach ($nombre in $pendientes) {
        if ($map.ContainsKey($nombre)) { $encontradasAqui += $nombre }
    }

    foreach ($nombre in $encontradasAqui) {
        $origen = $map[$nombre]
        $dest   = Join-Path $DestinoLocal $nombre

        try {
            Copiar-Carpeta -Origen $origen -Destino $dest
            Add-Content $LogEncontradas "OK | $nombre | $origen"
            $null = $pendientes.Remove($nombre)
            Write-Host "  Copiada: $nombre"
        } catch {
            Add-Content $LogErrores "ERROR copiando $nombre desde $origen $($_.Exception.Message)"
        }
    }
}

# ---------- 1) Tomar la PRIMERA carpeta dentro de RutaCompartida ----------
$primera = Get-ChildItem -Path $RutaCompartida -Directory -ErrorAction SilentlyContinue |
           Sort-Object FullName |
           Select-Object -First 1

if (-not $primera) {
    Write-Host "No encontré ninguna carpeta dentro de: $RutaCompartida"
    exit
}

Write-Host "Primera carpeta detectada: $($primera.FullName)"

# ---------- 2) Intentar nivel 6, si no existe bajar 5..1 ----------
$lotes = $null
$nivelUsado = $null

for ($nivel = 6; $nivel -ge 1; $nivel--) {
    $cand = Get-FoldersAtDepth -BasePath $primera.FullName -Depth $nivel
    if ($cand -and $cand.Count -gt 0) {
        $lotes = $cand
        $nivelUsado = $nivel
        break
    }
}

if (-not $lotes) {
    # Si ni siquiera hay subcarpetas, el lote es la misma primera carpeta
    $lotes = @($primera.FullName)
    $nivelUsado = 0
}

Write-Host "Usando nivel: $nivelUsado | Lotes a escanear: $($lotes.Count)"

# ---------- 3) Procesar cada lote ----------
foreach ($lote in $lotes) {
    if ($pendientes.Count -eq 0) { break }
    Procesar-Lote -RutaLote $lote
}

# ---------- 4) Guardar no encontradas ----------
foreach ($nombre in $pendientes) { Add-Content $LogNoEncontr $nombre }

Write-Host "=========================================="
Write-Host "FIN EJERCICIO 1 (solo primera carpeta)."
Write-Host "Encontradas: $((Get-Content $LogEncontradas | Where-Object { $_ -match '^OK' }).Count)"
Write-Host "No encontradas: $((Get-Content $LogNoEncontr).Count)"
Write-Host "Logs en: $LogDir"
Write-Host "=========================================="
