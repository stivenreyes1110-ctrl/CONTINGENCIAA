﻿# =========================
# RENOMBRAR PDF POR:
# (IDENTIFICADOR ANTES DE FEV) + (FEV) + (CORRECCION) + .pdf
# Base: C:\CONTINGENCIA
# Excel: C:\CONTINGENCIA\RELACION.xlsx
# Carpeta: C:\CONTINGENCIA\Antiguas
# =========================

$BasePath  = "C:\CONTINGENCIA"
$ExcelPath = Join-Path $BasePath "RELACION.xlsx"
$Antiguas  = Join-Path $BasePath "Antiguas"

if (!(Test-Path $ExcelPath)) { throw "No existe el Excel: $ExcelPath" }
if (!(Test-Path $Antiguas))  { throw "No existe la carpeta: $Antiguas" }

# --- ImportExcel ---
if (-not (Get-Module -ListAvailable -Name ImportExcel)) {
    Install-Module ImportExcel -Scope CurrentUser -Force -AllowClobber
}
Import-Module ImportExcel -ErrorAction Stop

$rows = Import-Excel -Path $ExcelPath
if (-not $rows -or $rows.Count -eq 0) { throw "El Excel está vacío o no se pudo leer." }

# Normaliza encabezados (quita tildes, espacios y símbolos)
function Normalize-Header([string]$s) {
    if ([string]::IsNullOrWhiteSpace($s)) { return "" }
    $t = $s.Trim().ToUpperInvariant()

    $t = $t.Normalize([Text.NormalizationForm]::FormD)
    $t = -join ($t.ToCharArray() | Where-Object {
        [Globalization.CharUnicodeInfo]::GetUnicodeCategory($_) -ne 'NonSpacingMark'
    })
    $t = $t.Normalize([Text.NormalizationForm]::FormC)

    return ($t -replace '[^A-Z0-9]', '')
}

# Mapa Normalizado -> Nombre real de columna
$props = $rows[0].PSObject.Properties.Name
$map = @{}
foreach ($p in $props) { $map[(Normalize-Header $p)] = $p }

function Resolve-Col([hashtable]$map, [string[]]$candidates, [string]$label) {
    foreach ($cand in $candidates) {
        $key = Normalize-Header $cand
        if ($map.ContainsKey($key)) { return $map[$key] }
    }
    throw "No encontré la columna '$label'. Encabezados detectados: $($map.Values -join ', ')"
}

# Columnas necesarias
$colDestino = Resolve-Col $map @("DESTINO") "DESTINO"
$colLugar   = Resolve-Col $map @("LUGAR")   "LUGAR"
$colFev     = Resolve-Col $map @("FEV")     "FEV (factor común)"
$colCorr    = Resolve-Col $map @("CORRECCION","CORRECION","CORRECCIÓN","CORRECIÓN") "CORRECCION/CORRECION"

foreach ($r in $rows) {

    $destino   = "$($r.$colDestino)".Trim()
    $lugar     = "$($r.$colLugar)".Trim()
    $fev       = "$($r.$colFev)".Trim()        # <-- factor común
    $correcion = "$($r.$colCorr)".Trim()       # <-- corrección a insertar

    if ([string]::IsNullOrWhiteSpace($fev)) {
        Write-Host "SKIP: fila sin FEV (factor común)"
        continue
    }

    # Carpeta: DESTINO primero, luego LUGAR
    $folderPath = $null
    if ($destino) {
        $try = Join-Path $Antiguas $destino
        if (Test-Path $try) { $folderPath = $try }
    }
    if (-not $folderPath -and $lugar) {
        $try = Join-Path $Antiguas $lugar
        if (Test-Path $try) { $folderPath = $try }
    }
    if (-not $folderPath) {
        Write-Host "NO_FOLDER: DESTINO='$destino' / LUGAR='$lugar' (FEV=$fev)"
        continue
    }

    # Buscar PDFs que contengan el FEV (factor común) en cualquier parte del nombre
    $matches = Get-ChildItem -Path $folderPath -File -Filter "*.pdf" -ErrorAction SilentlyContinue |
               Where-Object { $_.BaseName -like "*$fev*" } |
               Sort-Object Name

    if (-not $matches -or $matches.Count -eq 0) {
        Write-Host "NO_FILE: No encontré PDF que contenga '$fev' en '$folderPath'"
        continue
    }

    foreach ($file in $matches) {

        $base = $file.BaseName  # nombre sin .pdf
        $idx  = $base.IndexOf($fev, [System.StringComparison]::OrdinalIgnoreCase)

        if ($idx -lt 0) {
            Write-Host "SKIP: '$($file.Name)' no contiene '$fev' (raro, pero lo omito)"
            continue
        }

        # IDENTIFICADOR = todo lo que está ANTES de FEV (no se cambia)
        $identificador = $base.Substring(0, $idx)

        # Nuevo base = identificador + fev + correccion (sin “sobrantes” después)
        $newBase = if ([string]::IsNullOrWhiteSpace($correcion)) {
            "$identificador$fev"
        } else {
            "$identificador$fev$correcion"
        }

        $newName = "$newBase.pdf"
        $newPath = Join-Path $folderPath $newName

        if ($newName -eq $file.Name) {
            Write-Host "OK: Sin cambios '$($file.Name)'"
            continue
        }

        if (Test-Path $newPath) {
            Write-Host "CONFLICT: Ya existe '$newName' en '$folderPath' (no renombro '$($file.Name)')"
            continue
        }

        try {
            Rename-Item -Path $file.FullName -NewName $newName -ErrorAction Stop
            Write-Host "RENAMED: '$($file.Name)' -> '$newName' (carpeta: $folderPath)"
        } catch {
            Write-Host "ERROR: No pude renombrar '$($file.Name)'. Detalle: $($_.Exception.Message)"
        }
    }
}

Write-Host "`nProceso terminado."
