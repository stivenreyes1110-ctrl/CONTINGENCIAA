﻿# =========================
# RENOMBRAR ARCHIVOS NSB
# Cambia el número después de NSB
# =========================

$BasePath  = "C:\CONTINGENCIA"
$ExcelPath = Join-Path $BasePath "RELACION.xlsx"
$Antiguas  = Join-Path $BasePath "Antiguas"

if (!(Test-Path $ExcelPath)) { throw "No existe el Excel: $ExcelPath" }
if (!(Test-Path $Antiguas))  { throw "No existe la carpeta: $Antiguas" }

# --- ImportExcel ---
if (-not (Get-Module -ListAvailable -Name ImportExcel)) {
    Install-Module ImportExcel -Scope CurrentUser -Force -AllowClobber
}
Import-Module ImportExcel -ErrorAction Stop

$rows = Import-Excel -Path $ExcelPath
if (-not $rows -or $rows.Count -eq 0) { throw "El Excel está vacío o no se pudo leer." }

# --- Normalización columnas ---
function Normalize-Header([string]$s) {
    if ([string]::IsNullOrWhiteSpace($s)) { return "" }
    $t = $s.Trim().ToUpperInvariant()
    $t = $t.Normalize([Text.NormalizationForm]::FormD)
    $t = -join ($t.ToCharArray() | Where-Object {
        [Globalization.CharUnicodeInfo]::GetUnicodeCategory($_) -ne 'NonSpacingMark'
    })
    return ($t -replace '[^A-Z0-9]', '')
}

$props = $rows[0].PSObject.Properties.Name
$map = @{}
foreach ($p in $props) { $map[(Normalize-Header $p)] = $p }

function Resolve-Col([hashtable]$map, [string[]]$candidates) {
    foreach ($cand in $candidates) {
        $key = Normalize-Header $cand
        if ($map.ContainsKey($key)) { return $map[$key] }
    }
    throw "No encontré la columna: $($candidates -join ' / ')"
}

$colDestino = Resolve-Col $map @("DESTINO")
$colLugar   = Resolve-Col $map @("LUGAR")
$colCorr    = Resolve-Col $map @("CORRECCION","CORRECION","CORRECCIÓN")

# Regex para detectar archivos NSB + número
$rx = [regex]'^(NSB)(\d+)(.*)(\.pdf)$'

foreach ($r in $rows) {

    $destino = "$($r.$colDestino)".Trim()
    $lugar   = "$($r.$colLugar)".Trim()
    $corrRaw = "$($r.$colCorr)".Trim()

    # Dejar solo números en corrección
    $nuevoNumero = ($corrRaw -replace '[^0-9]', '')

    if ([string]::IsNullOrWhiteSpace($nuevoNumero)) {
        Write-Host "SKIP: fila sin número válido en CORRECCION"
        continue
    }

    # Buscar carpeta
    $folderPath = $null
    if ($destino) {
        $try = Join-Path $Antiguas $destino
        if (Test-Path $try) { $folderPath = $try }
    }
    if (-not $folderPath -and $lugar) {
        $try = Join-Path $Antiguas $lugar
        if (Test-Path $try) { $folderPath = $try }
    }
    if (-not $folderPath) {
        Write-Host "NO_FOLDER: $destino / $lugar"
        continue
    }

    # Buscar todos los PDF que empiecen por NSB
    $pdfs = Get-ChildItem -Path $folderPath -File -Filter "NSB*.pdf" -ErrorAction SilentlyContinue

    foreach ($file in $pdfs) {

        if ($rx.IsMatch($file.Name)) {

            $m = $rx.Match($file.Name)

            $prefijo = $m.Groups[1].Value   # NSB
            $resto   = $m.Groups[3].Value   # lo que viene después del número
            $ext     = $m.Groups[4].Value   # .pdf

            $nuevoNombre = "$prefijo$nuevoNumero$resto$ext"
            $nuevoPath = Join-Path $folderPath $nuevoNombre

            if ($nuevoNombre -eq $file.Name) {
                Write-Host "OK: '$($file.Name)' ya está correcto"
                continue
            }

            if (Test-Path $nuevoPath) {
                Write-Host "CONFLICT: Ya existe '$nuevoNombre'"
                continue
            }

            try {
                Rename-Item -Path $file.FullName -NewName $nuevoNombre -ErrorAction Stop
                Write-Host "RENAMED: '$($file.Name)' -> '$nuevoNombre'"
            }
            catch {
                Write-Host "ERROR: No pude renombrar '$($file.Name)'"
            }
        }
    }
}

Write-Host "`nProceso terminado."
