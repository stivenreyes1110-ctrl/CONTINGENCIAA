# ==========================================================
# COPIAR COINCIDENCIAS AL ESCRITORIO
# ==========================================================

$BasePath   = "C:\CONTINGENCIA"
$ExcelPath  = Join-Path $BasePath "RELACION.xlsx"

$NuevasPath = Join-Path $BasePath "NUEVAS"
$AntPath    = Join-Path $BasePath "ANTIGUAS"

# Escritorio din�mico del usuario actual
$DesktopPath = [Environment]::GetFolderPath("Desktop")
$CompPath    = Join-Path $DesktopPath "COMPROBADAS"
$CompNuevas  = Join-Path $CompPath "NUEVAS"
$CompAnt     = Join-Path $CompPath "ANTIGUAS"

# Crear estructura en escritorio
foreach ($p in @($CompPath, $CompNuevas, $CompAnt)) {
    if (!(Test-Path -LiteralPath $p)) {
        New-Item -ItemType Directory -Path $p | Out-Null
    }
}

function Normalize-Name {
    param([string]$s)
    if ($null -eq $s) { return "" }
    return ($s.Trim())
}

# Validaciones
foreach ($p in @($ExcelPath, $NuevasPath, $AntPath)) {
    if (!(Test-Path -LiteralPath $p)) {
        Write-Host "No existe: $p" -ForegroundColor Red
        exit
    }
}

# Abrir Excel
$excel = New-Object -ComObject Excel.Application
$excel.Visible = $false
$excel.DisplayAlerts = $false

$workbook = $excel.Workbooks.Open($ExcelPath)
$sheet = $workbook.Worksheets.Item(1)

$lastA = $sheet.Cells($sheet.Rows.Count, 1).End(-4162).Row
$lastB = $sheet.Cells($sheet.Rows.Count, 2).End(-4162).Row
$lastRow = [Math]::Max($lastA, $lastB)

Write-Host ""
Write-Host "COPIANDO COINCIDENCIAS AL ESCRITORIO..."
Write-Host "-------------------------------------------------"

$copiadas = 0

for ($row = 2; $row -le $lastRow; $row++) {

    $destino = Normalize-Name $sheet.Cells.Item($row,1).Value2
    $lugar   = Normalize-Name $sheet.Cells.Item($row,2).Value2

    if ([string]::IsNullOrWhiteSpace($destino) -or 
        [string]::IsNullOrWhiteSpace($lugar)) {
        continue
    }

    $srcNuevas = Join-Path $NuevasPath $lugar
    $srcAnt    = Join-Path $AntPath    $destino

    if ((Test-Path -LiteralPath $srcNuevas) -and 
        (Test-Path -LiteralPath $srcAnt)) {

        $tgtNuevas = Join-Path $CompNuevas $lugar
        $tgtAnt    = Join-Path $CompAnt    $destino

        Copy-Item -LiteralPath $srcNuevas -Destination $tgtNuevas -Recurse -Force
        Copy-Item -LiteralPath $srcAnt    -Destination $tgtAnt    -Recurse -Force

        Write-Host "Fila $row -> Copiadas ($lugar / $destino)" -ForegroundColor Green
        $copiadas++
    }
}

# Cerrar Excel
$workbook.Close($false)
$excel.Quit()
[System.Runtime.InteropServices.Marshal]::ReleaseComObject($sheet)    | Out-Null
[System.Runtime.InteropServices.Marshal]::ReleaseComObject($workbook) | Out-Null
[System.Runtime.InteropServices.Marshal]::ReleaseComObject($excel)    | Out-Null
[GC]::Collect()
[GC]::WaitForPendingFinalizers()

Write-Host "-------------------------------------------------"
Write-Host "Total coincidencias copiadas: $copiadas"
Write-Host "Proceso terminado correctamente."
