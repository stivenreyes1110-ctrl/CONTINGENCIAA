﻿# Ruta base
$RutaBase = "C:\CONTINGENCIA"
$RutaExcel = "C:\CONTINGENCIA\RELACION.xlsx"
$RutaCarpetas = "C:\CONTINGENCIA\ANTIGUAS"

# Verificar que exista el Excel
if (!(Test-Path $RutaExcel)) {
    Write-Host "No se encontró el archivo Excel en $RutaExcel" -ForegroundColor Red
    exit
}

# Crear objeto Excel
$Excel = New-Object -ComObject Excel.Application
$Excel.Visible = $false
$Workbook = $Excel.Workbooks.Open($RutaExcel)
$Hoja = $Workbook.Sheets.Item(1)

# Obtener última fila con datos
$UltimaFila = $Hoja.UsedRange.Rows.Count

# Recorrer filas (asumimos que fila 1 es encabezado)
for ($i = 2; $i -le $UltimaFila; $i++) {

    $Destino = $Hoja.Cells.Item($i, 1).Text.Trim()   # Columna DESTINO
    $Lugar   = $Hoja.Cells.Item($i, 2).Text.Trim()   # Columna LUGAR

    if ($Destino -and $Lugar) {

        $CarpetaActual = Join-Path $RutaCarpetas $Destino
        $NuevaRuta = Join-Path $RutaCarpetas $Lugar

        if (Test-Path $CarpetaActual) {

            # Verifica que no exista ya la nueva carpeta
            if (!(Test-Path $NuevaRuta)) {
                Rename-Item -Path $CarpetaActual -NewName $Lugar
                Write-Host "Carpeta '$Destino' renombrada a '$Lugar'" -ForegroundColor Green
            }
            else {
                Write-Host "Ya existe una carpeta llamada '$Lugar'. No se renombró '$Destino'." -ForegroundColor Yellow
            }

        }
        else {
            Write-Host "No existe la carpeta '$Destino' en ANTIGUAS" -ForegroundColor Red
        }
    }
}

# Cerrar Excel
$Workbook.Close($false)
$Excel.Quit()

# Liberar memoria
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($Excel) | Out-Null
Remove-Variable Excel

Write-Host "Proceso finalizado." -ForegroundColor Cyan

