﻿$BasePath  = "C:\CONTINGENCIA"
$ExcelPath = "$BasePath\RELACION.xlsx"
$Antiguas  = "$BasePath\ANTIGUAS"

# Validar rutas
if (!(Test-Path $ExcelPath)) { Write-Host "No existe el Excel: $ExcelPath" -ForegroundColor Red; return }
if (!(Test-Path $Antiguas))  { Write-Host "No existe la carpeta: $Antiguas" -ForegroundColor Red; return }

# Validar columnas del Excel (solo valida que estén)
$excel = New-Object -ComObject Excel.Application
$excel.Visible = $false
$excel.DisplayAlerts = $false

$libro = $excel.Workbooks.Open($ExcelPath)
$hoja  = $libro.Worksheets.Item(1)

$columnasNecesarias = @("DESTINO","LUGAR","ENTIDAD","CORRECCION","FEV")
$encabezados = @()

for ($i = 1; $i -le $hoja.UsedRange.Columns.Count; $i++) {
    $valor = $hoja.Cells.Item(1,$i).Text
    if ($valor) { $encabezados += $valor.Trim().ToUpper() }
}

foreach ($col in $columnasNecesarias) {
    if ($col -notin $encabezados) {
        Write-Host "Falta la columna $col en el Excel." -ForegroundColor Red
        $libro.Close($false); $excel.Quit()
        return
    }
}

$libro.Close($false)
$excel.Quit()

Write-Host "Excel validado correctamente." -ForegroundColor Green

# Procesar carpetas
$carpetas = Get-ChildItem $Antiguas -Directory

foreach ($carpeta in $carpetas) {

    Write-Host "`nProcesando: $($carpeta.FullName)" -ForegroundColor Cyan

    # Facturas disponibles (FACTURA*.pdf) - case insensitive
    $facturas = Get-ChildItem $carpeta.FullName -File |
                Where-Object { $_.Name -match '^(?i)FACTURA.*\.pdf$' } |
                Sort-Object Name

    if (!$facturas -or $facturas.Count -eq 0) {
        Write-Host "  No hay archivos FACTURA*.pdf para renombrar." -ForegroundColor Yellow
        continue
    }

    # ==========================================================
    # FUENTES: SOLO "NSB" + NUMERO + ".pdf" (exacto)
    # Ej: NSB1096100.pdf
    # NO toca: NSB1096100_SOP_1.pdf / NSB1096100_SOP_2.pdf
    # ==========================================================
    $fuentesNSB = Get-ChildItem $carpeta.FullName -File |
        Where-Object { $_.Name -match '^(?i)NSB\d+\.pdf$' } |
        Sort-Object Name

    if (!$fuentesNSB -or $fuentesNSB.Count -eq 0) {
        Write-Host "  No hay archivos fuente tipo NSB<NUMERO>.pdf (exacto)." -ForegroundColor Yellow
        continue
    }

    # Vamos renombrando una factura por cada fuente NSB (exacta)
    $idxFactura = 0

    foreach ($src in $fuentesNSB) {

        if ($idxFactura -ge $facturas.Count) {
            Write-Host "  ⚠ No hay más FACTURA*.pdf disponibles para asignar a '$($src.Name)'." -ForegroundColor Yellow
            break
        }

        $fact = $facturas[$idxFactura]
        $nuevoNombre = $src.Name

        # 1) BORRAR primero el archivo fuente NSB exacto
        Remove-Item -LiteralPath $src.FullName -Force

        # 2) Renombrar la FACTURA con ese nombre
        Rename-Item -LiteralPath $fact.FullName -NewName $nuevoNombre -Force

        Write-Host "  OK: '$($fact.Name)' -> '$nuevoNombre' (fuente NSB eliminada)" -ForegroundColor Green

        $idxFactura++
    }
}

Write-Host "`nProceso finalizado." -ForegroundColor Green
