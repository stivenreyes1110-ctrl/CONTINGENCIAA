﻿# ==========================================================
# Copiar archivos según RELACION.xlsx
# Base: C:\CONTINGENCIA
# NUEVAS\<LUGAR>\*  -->  ANTIGUAS\<DESTINO>\
# ==========================================================

$BasePath   = "C:\CONTINGENCIA"
$ExcelPath  = Join-Path $BasePath "RELACION.xlsx"
$NuevasPath = Join-Path $BasePath "NUEVAS"
$AntPath    = Join-Path $BasePath "ANTIGUAS"

# Validaciones
if (!(Test-Path $ExcelPath)) {
    Write-Host "❌ No existe el Excel en: $ExcelPath" -ForegroundColor Red
    exit
}
if (!(Test-Path $NuevasPath)) {
    Write-Host "❌ No existe la carpeta NUEVAS en: $NuevasPath" -ForegroundColor Red
    exit
}
if (!(Test-Path $AntPath)) {
    Write-Host "❌ No existe la carpeta ANTIGUAS en: $AntPath" -ForegroundColor Red
    exit
}

# Abrir Excel
$excel = New-Object -ComObject Excel.Application
$excel.Visible = $false
$excel.DisplayAlerts = $false

$workbook = $excel.Workbooks.Open($ExcelPath)
$sheet = $workbook.Worksheets.Item(1)

# Detectar última fila usada
$usedRange = $sheet.UsedRange
$lastRow = $usedRange.Rows.Count

Write-Host "📄 Leyendo Excel: $ExcelPath"
Write-Host "📌 Filas detectadas (incluye encabezado): $lastRow"
Write-Host "--------------------------------------------"

# Encabezados esperados:
# A: DESTINO
# B: LUGAR
# C: ARCHIVO
# D: ENTIDAD
# E: CORRECION

# Recorre desde la fila 2 (asumiendo fila 1 = encabezados)
for ($row = 2; $row -le $lastRow; $row++) {

    $destino = ($sheet.Cells.Item($row, 1).Text).Trim()
    $lugar   = ($sheet.Cells.Item($row, 2).Text).Trim()

    if ([string]::IsNullOrWhiteSpace($destino) -or [string]::IsNullOrWhiteSpace($lugar)) {
        Write-Host "⚠️ Fila $row ignorada (DESTINO o LUGAR vacío)."
        continue
    }

    $sourceFolder = Join-Path $NuevasPath $lugar
    $targetFolder = Join-Path $AntPath $destino

    if (!(Test-Path $sourceFolder)) {
        Write-Host "⚠️ Fila $row No existe carpeta origen: $sourceFolder" -ForegroundColor Yellow
        continue
    }

    if (!(Test-Path $targetFolder)) {
        New-Item -ItemType Directory -Path $targetFolder | Out-Null
        Write-Host "📁 Fila $row Creada carpeta destino: $targetFolder"
    }

    # Copiar todos los archivos (y subcarpetas si existen) desde LUGAR a DESTINO
    try {
        Copy-Item -Path (Join-Path $sourceFolder "*") -Destination $targetFolder -Recurse -Force
        Write-Host "✅ Fila $row Copiado desde '$lugar' --> '$destino'"
    }
    catch {
        Write-Host "❌ Fila $row Error copiando '$sourceFolder' a '$targetFolder' : $($_.Exception.Message)" -ForegroundColor Red
    }
}

# Cerrar Excel
$workbook.Close($false)
$excel.Quit()

# Liberar COM (evita que quede Excel abierto en segundo plano)
[System.Runtime.InteropServices.Marshal]::ReleaseComObject($sheet)    | Out-Null
[System.Runtime.InteropServices.Marshal]::ReleaseComObject($workbook) | Out-Null
[System.Runtime.InteropServices.Marshal]::ReleaseComObject($excel)    | Out-Null
[GC]::Collect()
[GC]::WaitForPendingFinalizers()

Write-Host "--------------------------------------------"
Write-Host "✅ Proceso terminado."
