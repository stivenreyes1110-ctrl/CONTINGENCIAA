@echo off
setlocal

REM ==========================================
REM Ejecuta los 4 scripts PowerShell en orden
REM Ruta fija: C:\CONTINGENCIA\RENOMBRAMIENTO 2026 PS1
REM ==========================================

set "BASE=C:\CONTINGENCIA\RENOMBRAMIENTO 2026 PS1\"

echo ==========================================
echo Ejecutando scripts desde: %BASE%
echo ==========================================

call :run "1.PASARFACTURA.ps1"
if errorlevel 1 goto :error

call :run "2.CAMBIONOMBRECARPETAS .ps1"
if errorlevel 1 goto :error

call :run "3.CAMBIARNOMBREARCHIVOS.ps1"
if errorlevel 1 goto :error

call :run "4.REMPLAZOFACTURA.ps1"
if errorlevel 1 goto :error

call :run "EPSRESTANTES.ps1"
if errorlevel 1 goto :error

call :run "REMPLAZO RESTO DE FACTURAS.ps1"
if errorlevel 1 goto :error

call :run "4.REVISARCONTENIDO.ps1"
if errorlevel 1 goto :error
echo.
echo ✅ TODOS LOS PROCESOS FINALIZARON CORRECTAMENTE.
pause
exit /b 0

:run
set "SCRIPT=%~1"
echo.
echo ▶ Ejecutando: %SCRIPT%
powershell -NoProfile -ExecutionPolicy Bypass -File "%BASE%%SCRIPT%"
exit /b %errorlevel%

:error
echo.
echo ❌ Se detuvo el proceso por un error.
pause
exit /b 1
