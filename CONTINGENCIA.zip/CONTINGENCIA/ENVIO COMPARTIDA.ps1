﻿# ==========================================================
# ENVIAR CONTINGENCIA A CARPETA COMPARTIDA
# - Copia TODO lo de C:\CONTINGENCIA\ANTIGUAS (carpetas)
# - Copia C:\CONTINGENCIA\RELACION.xlsx
# - Crea carpeta en \\128.0.9.5\facturacion\CONTINGENCIA\<NOMBRE>
# ==========================================================

$origenAntiguas = "C:\CONTINGENCIA\ANTIGUAS"
$origenExcel    = "C:\CONTINGENCIA\RELACION.xlsx"
$destinoRaiz    = "\\128.0.9.5\facturacion\CONTINGENCIA"

# -------- Validaciones --------
if (!(Test-Path $origenAntiguas)) { throw "❌ No existe la ruta: $origenAntiguas" }
if (!(Test-Path $origenExcel))    { throw "❌ No existe el archivo: $origenExcel" }
if (!(Test-Path $destinoRaiz))    { throw "❌ No tengo acceso o no existe: $destinoRaiz" }

# -------- Pedir nombre de carpeta --------
$nombreCarpeta = Read-Host "Escribe el nombre para la carpeta destino (ej: ENVIO_2026-02-18)"
$nombreCarpeta = $nombreCarpeta.Trim()

if ([string]::IsNullOrWhiteSpace($nombreCarpeta)) {
    throw "❌ El nombre de la carpeta no puede estar vacío."
}

# Limpiar caracteres inválidos para carpetas Windows
$invalid = [IO.Path]::GetInvalidFileNameChars()
foreach ($ch in $invalid) {
    $nombreCarpeta = $nombreCarpeta.Replace($ch, "_")
}

$destinoFinal = Join-Path $destinoRaiz $nombreCarpeta

# Si ya existe, crear sufijo
if (Test-Path $destinoFinal) {
    $i = 1
    do {
        $destinoFinal = Join-Path $destinoRaiz ("{0}_{1}" -f $nombreCarpeta, $i)
        $i++
    } while (Test-Path $destinoFinal)
}

New-Item -Path $destinoFinal -ItemType Directory -Force | Out-Null

# -------- Log --------
$log = Join-Path $destinoFinal ("LOG_ENVIO_" + (Get-Date -Format "yyyyMMdd_HHmmss") + ".txt")
function Write-Log { param([string]$t) Add-Content -Path $log -Encoding UTF8 -Value $t }

Write-Log "=== INICIO ENVIO $(Get-Date) ==="
Write-Log "Origen carpetas: $origenAntiguas"
Write-Log "Origen Excel: $origenExcel"
Write-Log "Destino: $destinoFinal"
Write-Log ""

# -------- Copiar Excel --------
try {
    Copy-Item -Path $origenExcel -Destination (Join-Path $destinoFinal (Split-Path $origenExcel -Leaf)) -Force
    Write-Log ("OK  | Excel copiado: {0}" -f $origenExcel)
} catch {
    Write-Log ("ERR | No se pudo copiar Excel: {0}" -f $_.Exception.Message)
    throw
}

# -------- Copiar carpetas (robocopy por carpeta) --------
function Copy-FolderRobust {
    param(
        [Parameter(Mandatory=$true)][string]$SourceFolder,
        [Parameter(Mandatory=$true)][string]$DestFolder
    )
    New-Item -Path $DestFolder -ItemType Directory -Force | Out-Null

    $args = @(
        "`"$SourceFolder`"",
        "`"$DestFolder`"",
        "/E",
        "/COPY:DAT",
        "/R:2","/W:1",
        "/NFL","/NDL","/NJH","/NJS","/NP"
    )

    $p = Start-Process -FilePath "robocopy.exe" -ArgumentList $args -Wait -PassThru
    return ($p.ExitCode -le 7)
}

$carpetas = Get-ChildItem -Path $origenAntiguas -Directory -ErrorAction SilentlyContinue

if ($carpetas.Count -eq 0) {
    Write-Log "WARN | No hay carpetas dentro de $origenAntiguas"
} else {
    Write-Host "📦 Copiando $($carpetas.Count) carpetas a la ruta compartida..." -ForegroundColor Cyan
}

$okCount = 0
$errCount = 0

foreach ($c in $carpetas) {
    $src = $c.FullName
    $dst = Join-Path $destinoFinal $c.Name

    # si ya existe, crear sufijo
    if (Test-Path $dst) {
        $j = 1
        do {
            $dst = Join-Path $destinoFinal ("{0}_{1}" -f $c.Name, $j)
            $j++
        } while (Test-Path $dst)
    }

    $ok = $false
    try {
        $ok = Copy-FolderRobust -SourceFolder $src -DestFolder $dst
    } catch {
        $ok = $false
    }

    if ($ok) {
        Write-Log ("OK  | Carpeta copiada: {0} => {1}" -f $src, $dst)
        $okCount++
    } else {
        Write-Log ("ERR | Falló carpeta: {0}" -f $src)
        $errCount++
    }
}

Write-Log ""
Write-Log ("Carpetas OK: {0}" -f $okCount)
Write-Log ("Carpetas ERROR: {0}" -f $errCount)
Write-Log "=== FIN ENVIO $(Get-Date) ==="

Write-Host "✅ Listo. Envío terminado." -ForegroundColor Green
Write-Host "Destino creado: $destinoFinal" -ForegroundColor Yellow
Write-Host "Log: $log" -ForegroundColor Yellow
