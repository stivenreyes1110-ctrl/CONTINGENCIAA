# ==========================================================
# MOVER COINCIDENCIAS A COMPROBADAS CON CARPETA POR FECHA
# Base: C:\CONTINGENCIA
# ==========================================================

$BasePath   = "C:\CONTINGENCIA"
$ExcelPath  = Join-Path $BasePath "RELACION.xlsx"

$NuevasPath = Join-Path $BasePath "NUEVAS"
$AntPath    = Join-Path $BasePath "ANTIGUAS"
$CompBase   = Join-Path $BasePath "COMPROBADAS"

# ========= CREAR CARPETA CON FECHA =========
$FechaRun = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$CompPath = Join-Path $CompBase $FechaRun

if (!(Test-Path $CompPath)) {
    New-Item -ItemType Directory -Path $CompPath -Force | Out-Null
    Write-Host "📁 Carpeta de prueba creada: $CompPath"
} else {
    Write-Host "📁 Carpeta ya existe: $CompPath"
}

# ========= ABRIR EXCEL =========
$Excel = New-Object -ComObject Excel.Application
$Excel.Visible = $false
$Workbook = $Excel.Workbooks.Open($ExcelPath)
$Sheet = $Workbook.Sheets.Item(1)
$UsedRange = $Sheet.UsedRange
$Rows = $UsedRange.Rows.Count

Write-Host "🔎 Iniciando comprobación..."

for ($i = 2; $i -le $Rows; $i++) {

    $Destino = $Sheet.Cells.Item($i,1).Text.Trim()
    $Lugar   = $Sheet.Cells.Item($i,2).Text.Trim()

    $CarpetaAnt = Join-Path $AntPath $Destino
    $CarpetaNue = Join-Path $NuevasPath $Lugar

    if ((Test-Path $CarpetaAnt) -and (Test-Path $CarpetaNue)) {

        $DestinoFinal = Join-Path $CompPath $Destino

        # Si no existe la carpeta destino, crearla
        if (!(Test-Path $DestinoFinal)) {
            New-Item -ItemType Directory -Path $DestinoFinal | Out-Null
        }

        # Copiar contenido de ANTIGUAS
        Copy-Item "$CarpetaAnt\*" -Destination $DestinoFinal -Recurse -Force

        # Copiar contenido de NUEVAS
        Copy-Item "$CarpetaNue\*" -Destination $DestinoFinal -Recurse -Force

        Write-Host "✅ Copiado: $Destino"

    } else {

        Write-Host "❌ No coincide: $Destino - $Lugar"

    }
}

# ========= CERRAR EXCEL =========
$Workbook.Close($false)
$Excel.Quit()
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($Excel) | Out-Null

Write-Host "🎯 Proceso finalizado."
    