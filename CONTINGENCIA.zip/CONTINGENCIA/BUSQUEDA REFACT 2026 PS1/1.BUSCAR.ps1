﻿# ======================================================
# BUSCAR CARPETAS POR COLUMNA DESTINO Y COPIARLAS
# BUSQUEDA EN RED: \\128.0.9.5\facturacion
# ======================================================

# ---- RUTA DE BUSQUEDA (RED)
$raizFacturacion = "\\128.0.9.5\facturacion"

# ---- EXCEL
$rutaExcel       = "C:\CONTINGENCIA\RELACION.xlsx"

# ---- DESTINO DE COPIA
$destinoBase     = "C:\CONTINGENCIA\ANTIGUAS"

# ---- CONFIGURACIÓN EXCEL
$columnaDestino  = "DESTINO"   # encabezado exacto en Excel
$hojaNombre      = ""          # "" = primera hoja

# ---- VALIDACIONES
if (!(Test-Path $raizFacturacion)) { throw "❌ No tengo acceso o no existe: $raizFacturacion" }
if (!(Test-Path $rutaExcel))       { throw "❌ No existe el Excel: $rutaExcel" }

New-Item -Path $destinoBase -ItemType Directory -Force | Out-Null

$log = Join-Path $destinoBase ("LOG_" + (Get-Date -Format "yyyyMMdd_HHmmss") + ".txt")

function Write-Log {
    param([string]$Texto)
    Add-Content -Path $log -Encoding UTF8 -Value $Texto
}

Write-Log "=== INICIO $(Get-Date) ==="
Write-Log "Excel: $rutaExcel"
Write-Log "Buscar en: $raizFacturacion"
Write-Log "Destino: $destinoBase"
Write-Log ""

# ======================================================
# FUNCIÓN PARA COPIAR CARPETAS (ROBUSTA)
# ======================================================
function Copy-FolderRobust {
    param(
        [Parameter(Mandatory=$true)][string]$SourceFolder,
        [Parameter(Mandatory=$true)][string]$DestFolder
    )

    New-Item -Path $DestFolder -ItemType Directory -Force | Out-Null

    $args = @(
        "`"$SourceFolder`"",
        "`"$DestFolder`"",
        "/E",
        "/COPY:DAT",
        "/R:2","/W:1",
        "/NFL","/NDL","/NJH","/NJS","/NP"
    )

    $p = Start-Process -FilePath "robocopy.exe" -ArgumentList $args -Wait -PassThru
    return ($p.ExitCode -le 7)
}

# ======================================================
# ABRIR EXCEL Y LEER DESTINO
# ======================================================
$excel = New-Object -ComObject Excel.Application
$excel.Visible = $false
$excel.DisplayAlerts = $false

try {
    $wb = $excel.Workbooks.Open($rutaExcel)

    if ([string]::IsNullOrWhiteSpace($hojaNombre)) {
        $ws = $wb.Worksheets.Item(1)
    } else {
        $ws = $wb.Worksheets.Item($hojaNombre)
    }

    $used = $ws.UsedRange
    $rows = $used.Rows.Count
    $cols = $used.Columns.Count

    if ($rows -lt 2) { throw "❌ El Excel no tiene datos (mínimo encabezado + 1 fila)." }

    # ---- Encontrar columna DESTINO
    $colIndex = $null
    for ($c = 1; $c -le $cols; $c++) {
        $header = ($ws.Cells.Item(1, $c).Text).Trim()
        if ($header -ieq $columnaDestino) { $colIndex = $c; break }
    }
    if (-not $colIndex) { throw "❌ No encontré la columna '$columnaDestino' en la fila 1." }

    # ---- Leer valores DESTINO
    $facturas = @()
    for ($r = 2; $r -le $rows; $r++) {
        $valor = ($ws.Cells.Item($r, $colIndex).Text).Trim()
        if (![string]::IsNullOrWhiteSpace($valor)) { $facturas += $valor }
    }
    if ($facturas.Count -eq 0) { throw "❌ La columna '$columnaDestino' está vacía." }

    Write-Host "🔎 Indexando carpetas en red... (puede tardar)" -ForegroundColor Cyan
    Write-Host "Ruta: $raizFacturacion" -ForegroundColor Cyan

    # ---- Indexar todas las carpetas del recurso compartido
    $allFolders = Get-ChildItem -Path $raizFacturacion -Recurse -Directory -ErrorAction SilentlyContinue

    $map = @{}
    foreach ($folder in $allFolders) {
        $nombre = $folder.Name.Trim()
        if (-not $map.ContainsKey($nombre)) { $map[$nombre] = @() }
        $map[$nombre] += $folder.FullName
    }

    $copiadas = 0
    $noEncontradas = 0

    foreach ($f in $facturas) {
        if ($map.ContainsKey($f)) {
            foreach ($rutaOrigen in $map[$f]) {

                $destinoFinal = Join-Path $destinoBase $f
                if (Test-Path $destinoFinal) {
                    $i = 1
                    do {
                        $destinoFinal = Join-Path $destinoBase ("$f" + "_" + $i)
                        $i++
                    } while (Test-Path $destinoFinal)
                }

                $ok = Copy-FolderRobust -SourceFolder $rutaOrigen -DestFolder $destinoFinal

                if ($ok) {
                    Write-Log ("OK  | {0} | {1} => {2}" -f $f, $rutaOrigen, $destinoFinal)
                    $copiadas++
                } else {
                    Write-Log ("ERR | {0} | Error copiando {1}" -f $f, $rutaOrigen)
                }
            }
        } else {
            Write-Log ("NO  | {0} | No encontrada carpeta" -f $f)
            $noEncontradas++
        }
    }

    Write-Log ""
    Write-Log "Copiadas: $copiadas"
    Write-Log "No encontradas: $noEncontradas"
    Write-Log "=== FIN $(Get-Date) ==="

    Write-Host "✅ Proceso terminado" -ForegroundColor Green
    Write-Host "Copiadas: $copiadas"
    Write-Host "No encontradas: $noEncontradas"
    Write-Host "Log: $log" -ForegroundColor Yellow
}
finally {
    if ($wb) { $wb.Close($false) | Out-Null }
    $excel.Quit() | Out-Null
    [System.Runtime.InteropServices.Marshal]::ReleaseComObject($excel) | Out-Null
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
