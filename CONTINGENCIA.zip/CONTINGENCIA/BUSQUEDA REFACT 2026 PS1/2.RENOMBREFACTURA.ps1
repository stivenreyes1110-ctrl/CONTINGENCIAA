# ==========================================================
# RENOMBRAR PDFs DENTRO DE CADA CARPETA A: FACTURA.pdf
# Base: C:\CONTINGENCIA\CARPETAS
# ==========================================================

$BasePath = "C:\CONTINGENCIA\NUEVAS"
$TimeStamp = Get-Date -Format "yyyyMMdd_HHmmss"

$LogOK       = "C:\CONTINGENCIA\LOG_RENOMBRADOS_$TimeStamp.txt"
$LogError    = "C:\CONTINGENCIA\LOG_ERRORES_RENOMBRADO_$TimeStamp.txt"
$LogSkipped  = "C:\CONTINGENCIA\LOG_SALTADOS_$TimeStamp.txt"

$CountOK = 0
$CountError = 0
$CountSkipped = 0

if (!(Test-Path $BasePath)) {
    throw "❌ No existe la ruta: $BasePath"
}

# Obtener todas las subcarpetas
$carpetas = Get-ChildItem -Path $BasePath -Directory

foreach ($carpeta in $carpetas) {

    try {

        # Buscar PDFs dentro de la carpeta
        $pdfs = Get-ChildItem -Path $carpeta.FullName -Filter "*.pdf" -File

        if ($pdfs.Count -eq 0) {
            "SIN PDF | $($carpeta.Name)" | Out-File $LogSkipped -Append -Encoding UTF8
            $CountSkipped++
            continue
        }

        # Tomamos el primer PDF encontrado
        $pdf = $pdfs[0]
        $nuevoNombre = Join-Path $carpeta.FullName "FACTURA.pdf"

        # Si ya existe FACTURA.pdf
        if (Test-Path $nuevoNombre) {
            "YA EXISTE FACTURA | $($carpeta.Name)" | Out-File $LogSkipped -Append -Encoding UTF8
            $CountSkipped++
            continue
        }

        Rename-Item -Path $pdf.FullName -NewName "FACTURA.pdf"
        "RENOMBRADO | $($carpeta.Name) | $($pdf.Name) -> FACTURA.pdf" | Out-File $LogOK -Append -Encoding UTF8
        $CountOK++
    }
    catch {
        "ERROR | $($carpeta.Name) | $($_.Exception.Message)" | Out-File $LogError -Append -Encoding UTF8
        $CountError++
    }
}

# Resumen en pantalla
Write-Host ""
Write-Host "=========== RESUMEN ===========" -ForegroundColor Cyan
Write-Host "Renombrados : $CountOK" -ForegroundColor Green
Write-Host "Saltados    : $CountSkipped" -ForegroundColor Yellow
Write-Host "Errores     : $CountError" -ForegroundColor Red
Write-Host "================================" -ForegroundColor Cyan
Write-Host "Logs guardados en C:\CONTINGENCIA"
