﻿# ==========================================================
# LISTAR CARPETAS Y CONTENIDO (ANTIGUAS)
# Base fija: C:\CONTINGENCIA
# Carpeta:  C:\CONTINGENCIA\ANTIGUAS
# Enumera carpetas y lista archivos dentro de cada una
# ==========================================================

$BasePath     = "C:\CONTINGENCIA"
$AntiguasPath = Join-Path $BasePath "ANTIGUAS"

# Reporte en TXT
$OutReport = Join-Path $BasePath ("REPORTE_ANTIGUAS_" + (Get-Date -Format "yyyyMMdd_HHmmss") + ".txt")

function Stop-WithMessage($msg) {
    Write-Host "❌ $msg" -ForegroundColor Red
    throw $msg
}

if (!(Test-Path $AntiguasPath)) {
    Stop-WithMessage "No existe la ruta: $AntiguasPath"
}

"==========================================================" | Out-File -FilePath $OutReport -Encoding UTF8
"REPORTE - LISTADO DE CARPETAS Y ARCHIVOS (ANTIGUAS)"        | Out-File -FilePath $OutReport -Append -Encoding UTF8
"Ruta: $AntiguasPath"                                       | Out-File -FilePath $OutReport -Append -Encoding UTF8
"Fecha: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"          | Out-File -FilePath $OutReport -Append -Encoding UTF8
"==========================================================" | Out-File -FilePath $OutReport -Append -Encoding UTF8
""                                                          | Out-File -FilePath $OutReport -Append -Encoding UTF8

Write-Host "🔎 Listando carpetas en: $AntiguasPath" -ForegroundColor Cyan

$folders = Get-ChildItem -Path $AntiguasPath -Directory | Sort-Object Name

if (-not $folders -or $folders.Count -eq 0) {
    Write-Host "⚠️ No hay carpetas dentro de ANTIGUAS." -ForegroundColor Yellow
    "No se encontraron carpetas dentro de ANTIGUAS." | Out-File -FilePath $OutReport -Append -Encoding UTF8
}
else {
    $i = 1
    foreach ($f in $folders) {

        $header = ("[{0:000}] CARPETA: {1}" -f $i, $f.Name)
        Write-Host $header -ForegroundColor White

        $header | Out-File -FilePath $OutReport -Append -Encoding UTF8
        ("Ruta: " + $f.FullName) | Out-File -FilePath $OutReport -Append -Encoding UTF8

        # Archivos SOLO dentro de la carpeta (sin subcarpetas)
        $files = Get-ChildItem -Path $f.FullName -File | Sort-Object Name

        if (-not $files -or $files.Count -eq 0) {
            Write-Host "   - (sin archivos)" -ForegroundColor DarkYellow
            "   - (sin archivos)" | Out-File -FilePath $OutReport -Append -Encoding UTF8
        }
        else {
            "  Archivos:" | Out-File -FilePath $OutReport -Append -Encoding UTF8
            foreach ($file in $files) {
                $sizeKB = [math]::Round($file.Length / 1KB, 1)
                $row = ("   - {0} | {1} KB | {2}" -f $file.Name, $sizeKB, $file.LastWriteTime.ToString("yyyy-MM-dd HH:mm"))
                Write-Host $row -ForegroundColor Gray
                $row | Out-File -FilePath $OutReport -Append -Encoding UTF8
            }
        }

        "" | Out-File -FilePath $OutReport -Append -Encoding UTF8
        $i++
    }
}

Write-Host ""
Write-Host "✅ Listo. Reporte generado en:" -ForegroundColor Green
Write-Host "   $OutReport" -ForegroundColor Green
