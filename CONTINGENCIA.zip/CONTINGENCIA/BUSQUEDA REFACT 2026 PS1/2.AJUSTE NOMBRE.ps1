﻿# ==========================================================
# SOLO RENOMBRAR ARCHIVOS DENTRO DE ANTIGUAS (NO CARPETAS)
# Excel: C:\CONTINGENCIA\RELACION.xlsx (Hoja 1)
# Usa columnas: DESTINO, FEV
# Carpeta raíz: C:\CONTINGENCIA\ANTIGUAS
# Renombre: Original -> Original_FEV_DESTINO.ext
# ==========================================================

$BasePath   = "C:\CONTINGENCIA"
$ExcelPath  = Join-Path $BasePath "RELACION.xlsx"
$Antiguas   = Join-Path $BasePath "ANTIGUAS"
$LogPath    = Join-Path $BasePath ("LOG_RENOMBRE_ARCHIVOS_{0}.txt" -f (Get-Date -Format "yyyyMMdd_HHmmss"))

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $line = "[{0}] [{1}] {2}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Level, $Message
    $line | Tee-Object -FilePath $LogPath -Append
}

function Sanitize-Name {
    param([string]$Name)
    if ([string]::IsNullOrWhiteSpace($Name)) { return "" }
    $invalid = [System.IO.Path]::GetInvalidFileNameChars()
    foreach ($c in $invalid) { $Name = $Name.Replace($c, '_') }
    return $Name.Trim()
}

function Get-UniqueName {
    param(
        [string]$Directory,
        [string]$BaseName,
        [string]$Extension
    )
    $i = 0
    do {
        $suffix = if ($i -eq 0) { "" } else { "_$i" }
        $candidate = Join-Path $Directory ($BaseName + $suffix + $Extension)
        $i++
    } while (Test-Path $candidate)

    return (Split-Path $candidate -Leaf)
}

# =========================
# Validaciones
# =========================
if (!(Test-Path $ExcelPath)) { Write-Host "No existe el Excel: $ExcelPath" -ForegroundColor Red; return }
if (!(Test-Path $Antiguas))  { Write-Host "No existe la carpeta: $Antiguas" -ForegroundColor Red; return }

Write-Log "Inicio. Antiguas=$Antiguas | Excel=$ExcelPath"

# =========================
# Leer Excel (COM)
# =========================
$excel = $null
$libro = $null
$hoja  = $null

try {
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false

    $libro = $excel.Workbooks.Open($ExcelPath)
    $hoja  = $libro.Worksheets.Item(1)

    # Mapear encabezados (fila 1)
    $usedCols = $hoja.UsedRange.Columns.Count
    $colMap = @{}
    for ($c = 1; $c -le $usedCols; $c++) {
        $header = $hoja.Cells.Item(1, $c).Text
        if (![string]::IsNullOrWhiteSpace($header)) {
            $colMap[$header.Trim().ToUpper()] = $c
        }
    }

    foreach ($req in @("DESTINO","FEV")) {
        if (-not $colMap.ContainsKey($req)) {
            throw "Falta la columna requerida '$req' en el Excel (fila 1)."
        }
    }

    $colDestino = $colMap["DESTINO"]
    $colFev     = $colMap["FEV"]

    $lastRow = $hoja.UsedRange.Rows.Count
    if ($lastRow -lt 2) { throw "El Excel no tiene datos (solo encabezados)." }

    # DESTINO -> FEV (toma el primero válido)
    $destinoToFev = @{}
    for ($r = 2; $r -le $lastRow; $r++) {
        $destino = ($hoja.Cells.Item($r, $colDestino).Text).Trim()
        $fev     = ($hoja.Cells.Item($r, $colFev).Text).Trim()

        if ([string]::IsNullOrWhiteSpace($destino)) { continue }
        if ([string]::IsNullOrWhiteSpace($fev))     { continue }

        $destino = Sanitize-Name $destino
        $fev     = Sanitize-Name $fev

        if (-not $destinoToFev.ContainsKey($destino)) {
            $destinoToFev[$destino] = $fev
        }
    }

    Write-Log ("DESTINOS con FEV encontrados en Excel: {0}" -f $destinoToFev.Count)

    # =========================
    # Recorrer carpetas en ANTIGUAS (sin renombrarlas)
    # =========================
    $folders = Get-ChildItem -Path $Antiguas -Directory -ErrorAction Stop

    foreach ($folder in $folders) {
        $dest = $folder.Name

        if (-not $destinoToFev.ContainsKey($dest)) {
            Write-Log "Carpeta '$dest' no está en Excel (DESTINO). Se omite." "WARN"
            continue
        }

        $fev = $destinoToFev[$dest]
        Write-Log "Procesando carpeta '$dest' con FEV='$fev'"

        $files = Get-ChildItem -Path $folder.FullName -File -ErrorAction SilentlyContinue
        foreach ($f in $files) {
            $base = Sanitize-Name $f.BaseName
            $ext  = $f.Extension

            $suffix = "_$fev`_$dest"
            if ($base.ToUpper().EndsWith($suffix.ToUpper())) {
                Write-Log "Ya tiene sufijo (omite): '$($f.Name)'"
                continue
            }

            $newBase = Sanitize-Name ("{0}_{1}_{2}" -f $base, $fev, $dest)
            $newName = Get-UniqueName -Directory $folder.FullName -BaseName $newBase -Extension $ext

            try {
                Rename-Item -Path $f.FullName -NewName $newName -ErrorAction Stop
                Write-Log "Renombrado: '$($f.Name)' -> '$newName'"
            } catch {
                Write-Log "ERROR renombrando '$($f.Name)': $($_.Exception.Message)" "ERROR"
            }
        }
    }

    Write-Log "Finalizado OK. Log: $LogPath"
    Write-Host "✅ Listo. Revisa el log en: $LogPath" -ForegroundColor Green
}
catch {
    Write-Log "FALLO GENERAL: $($_.Exception.Message)" "ERROR"
    Write-Host "❌ Error: $($_.Exception.Message)" -ForegroundColor Red
}
finally {
    if ($libro) { $libro.Close($false) | Out-Null }
    if ($excel) { $excel.Quit() | Out-Null }

    foreach ($obj in @($hoja,$libro,$excel)) {
        if ($obj) { [System.Runtime.InteropServices.Marshal]::ReleaseComObject($obj) | Out-Null }
    }

    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
