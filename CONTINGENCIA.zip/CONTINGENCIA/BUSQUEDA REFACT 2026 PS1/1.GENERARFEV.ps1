﻿# ==========================================================
# GENERAR FV.pdf O FEV.pdf (ELIGE) EN CARPETAS DESTINO (Excel)
# Ruta base: C:\CONTINGENCIA
# Excel: C:\CONTINGENCIA\RELACION.xlsx (Hoja 1)
# Crea: FV.pdf o FEV.pdf dentro de ANTIGUAS\<DESTINO>\
# ==========================================================

$BasePath  = "C:\CONTINGENCIA"
$ExcelPath = Join-Path $BasePath "RELACION.xlsx"
$Antiguas  = Join-Path $BasePath "ANTIGUAS"
$LogPath   = Join-Path $BasePath ("LOG_GEN_FV_FEV_{0}.txt" -f (Get-Date -Format "yyyyMMdd_HHmmss"))

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $line = "[{0}] [{1}] {2}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Level, $Message
    $line | Tee-Object -FilePath $LogPath -Append
}

function New-MinimalPdf {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [string]$Title = "Documento generado",
        [string]$BodyText = "PDF generado automaticamente"
    )

    $content = @"
%PDF-1.4
1 0 obj
<< /Type /Catalog /Pages 2 0 R >>
endobj
2 0 obj
<< /Type /Pages /Kids [3 0 R] /Count 1 >>
endobj
3 0 obj
<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>
endobj
4 0 obj
<< /Length 170 >>
stream
BT
/F1 18 Tf
72 740 Td
($Title) Tj
/F1 12 Tf
72 710 Td
($BodyText) Tj
72 690 Td
(Fecha: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")) Tj
ET
endstream
endobj
5 0 obj
<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>
endobj
xref
0 6
0000000000 65535 f 
trailer
<< /Size 6 /Root 1 0 R >>
startxref
0
%%EOF
"@
    [System.IO.File]::WriteAllText($Path, $content, [System.Text.Encoding]::ASCII)
}

# Validaciones
if (!(Test-Path $ExcelPath)) { Write-Host "No existe el Excel: $ExcelPath" -ForegroundColor Red; return }
if (!(Test-Path $Antiguas))  { Write-Host "No existe la carpeta: $Antiguas" -ForegroundColor Red; return }

# Menú
Write-Host ""
Write-Host "¿Qué PDF quieres generar?" -ForegroundColor Cyan
Write-Host "  1) FV.pdf"
Write-Host "  2) FEV.pdf"
$opt = Read-Host "Elige 1 o 2"

$pdfName = switch ($opt) {
    "1" { "FV.pdf" }
    "2" { "FEV.pdf" }
    default {
        Write-Host "Opción inválida. Debe ser 1 o 2." -ForegroundColor Red
        return
    }
}

Write-Log "Inicio. Generar '$pdfName' en carpetas DESTINO."

# Leer Excel (COM)
$excel = $null; $libro = $null; $hoja = $null

try {
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false

    $libro = $excel.Workbooks.Open($ExcelPath)
    $hoja  = $libro.Worksheets.Item(1)

    # Buscar columna DESTINO por encabezado
    $usedCols = $hoja.UsedRange.Columns.Count
    $colDestino = $null

    for ($c = 1; $c -le $usedCols; $c++) {
        $h = ($hoja.Cells.Item(1, $c).Text).Trim()
        if ($h.ToUpper() -eq "DESTINO") { $colDestino = $c; break }
    }
    if (-not $colDestino) { throw "No encontré la columna DESTINO en la fila 1." }

    $lastRow = $hoja.UsedRange.Rows.Count
    if ($lastRow -lt 2) { throw "El Excel no tiene datos (solo encabezados)." }

    # DESTINOS únicos
    $destinos = New-Object System.Collections.Generic.HashSet[string]
    for ($r = 2; $r -le $lastRow; $r++) {
        $d = ($hoja.Cells.Item($r, $colDestino).Text).Trim()
        if (![string]::IsNullOrWhiteSpace($d)) { [void]$destinos.Add($d) }
    }

    Write-Log ("DESTINOS encontrados: {0}" -f $destinos.Count)

    foreach ($dest in $destinos) {
        $folder = Join-Path $Antiguas $dest
        if (!(Test-Path $folder)) {
            Write-Log "No existe carpeta en ANTIGUAS para DESTINO='$dest' (se omite)" "WARN"
            continue
        }

        $pdfPath = Join-Path $folder $pdfName

        if (Test-Path $pdfPath) {
            Write-Log "Ya existe $pdfName en '$dest' (se omite)"
            continue
        }

        $title = ($pdfName -replace "\.pdf$","")
        New-MinimalPdf -Path $pdfPath -Title $title -BodyText "Archivo $title generado para carpeta: $dest"
        Write-Log "Creado: $pdfPath"
    }

    Write-Log "Finalizado OK. Log: $LogPath"
    Write-Host "✅ Listo. Revisa el log: $LogPath" -ForegroundColor Green
}
catch {
    Write-Log "ERROR: $($_.Exception.Message)" "ERROR"
    Write-Host "❌ Error: $($_.Exception.Message)" -ForegroundColor Red
}
finally {
    if ($libro) { $libro.Close($false) | Out-Null }
    if ($excel) { $excel.Quit() | Out-Null }
    foreach ($obj in @($hoja,$libro,$excel)) {
        if ($obj) { [System.Runtime.InteropServices.Marshal]::ReleaseComObject($obj) | Out-Null }
    }
    [GC]::Collect(); [GC]::WaitForPendingFinalizers()
}