﻿# Rutas de las carpetas
$carpetas = @(
    "C:\CONTINGENCIA\ANTIGUAS",
    "C:\CONTINGENCIA\NUEVAS"
)

foreach ($carpeta in $carpetas) {

    if (Test-Path $carpeta) {

        Write-Host "Procesando carpeta: $carpeta"

        # Limpiar todo el contenido de la carpeta
        Get-ChildItem -Path $carpeta -Recurse -Force -ErrorAction SilentlyContinue |
        Remove-Item -Recurse -Force -ErrorAction SilentlyContinue

        Write-Host "Carpeta limpiada correctamente.`n"
    }
    else {
        Write-Host "La carpeta no existe: $carpeta`n"
    }
}

Write-Host "Proceso finalizado."
